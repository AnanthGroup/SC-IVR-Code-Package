#!/bin/bash
mkdir ../../EXPERIMENT
cp ../jobrun.sh ../../EXPERIMENT
cd ../../
cp Source_Adiabatic/makefiles/Makefile EXPERIMENT
cp Source_Adiabatic/supply/supply_1D.f90 EXPERIMENT
cp Source_Adiabatic/params/params_1D.f90 EXPERIMENT
cp Source_Adiabatic/timecorr/FBG_MQC_timecorr_1D.f90 EXPERIMENT
cp Source_Adiabatic/traj/traj_1D.f90 EXPERIMENT
cp Source_Adiabatic/monteCarlo/MonteCarlo_1D.f90 EXPERIMENT
cp Source_Adiabatic/potentials/potential_1D.f90 EXPERIMENT
cp theory.in input_1D
mv input_1D EXPERIMENT
cd Scripts/MoveFiles
