#!/bin/bash
rm -r EXPERIMENT
LINES=()
while IFS= read -r line
do
  LINES[${#LINES[@]}]="$line"
done < "theory.in"
Dimens=${LINES[1]}
Theory=${LINES[3]}
Implem=${LINES[5]}
Operat=${LINES[7]}
Potent=${LINES[9]}

if [ $Theory -eq "1" -a $Implem -eq "2" ]; then   #Flag FB DHK-IVR
echo
echo
echo 'Forward-Backward DHK-IVR has not been configured, use Forward-Forward'
echo
echo

elif [ $Implem -eq "1" -a $Operat -eq "3" ]; then
echo
echo
echo 'The "General" option is specific to the Forward-Backward MQC-IVR.'
echo 'Choose position ( B = q ) or momentum ( B = p ) when using	'
echo 'forward-forward methods'
echo
echo

elif [ $Theory -eq "4" -a $Operat -eq "2" ]; then #Flag LSC-IVR with B=B(p)
echo
echo
echo 'LSC-IVR has not been Configured with a Momentum Observable'
echo
echo

elif [ $Theory -eq "2" -a $Implem -eq "2" ]; then #Flag FB Hus-IVR and LSC-IVR
echo
echo
echo 'With Husimi and LSC-IVR please use Forward-Forward Setting'
echo
echo

elif [ $Theory -eq "4" -a $Implem -eq "2" ]; then #Flag FB Hus-IVR and LSC-IVR
echo
echo
echo 'With Husimi and LSC-IVR, please use the Forward-Forward Setting'
echo
echo

elif [ $Dimens -gt "1" -a "$Potent" -eq "1" ]; then #Flag Harmonic Pot with mD
echo
echo
echo 'Multidimensional harmonic system not configured, switch to anharmonic potential'
echo
echo

elif [ $Dimens -lt "3" ] 
then
 cd Scripts/MoveFiles/
 sh $Dimens-$Theory-$Implem-$Operat.sh
 cp ../SearchReplace/$Dimens-$Theory-$Implem-$Operat-$Potent.sh ../../EXPERIMENT
 cd ../../EXPERIMENT
 sh $Dimens-$Theory-$Implem-$Operat-$Potent.sh
 rm *-$Potent.sh
 cd ../
else
 cd Scripts/MoveFiles/
 sh 2-$Theory-$Implem-$Operat.sh
 cp ../SearchReplace/2-$Theory-$Implem-$Operat-$Potent.sh ../../EXPERIMENT
 cd ../../EXPERIMENT
 sh 2-$Theory-$Implem-$Operat-$Potent.sh
 rm *-$Potent.sh
 cd ../
fi
