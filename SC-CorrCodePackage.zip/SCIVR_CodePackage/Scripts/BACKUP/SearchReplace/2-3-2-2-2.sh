#!/bin/bash
sed -i 's/timecorr.f90/FB_MQC_timecorr_mD.f90/g' Makefile
sed -i 's/supply.f90/supply_mD.f90/g' Makefile
sed -i 's/traj.f90/traj_mD.f90/g' Makefile
sed -i 's/MonteCarlo.f90/MonteCarlo_mD.f90/g' Makefile
sed -i 's/params/params_mD/g' Makefile
sed -i 's/potential.f90/potential_mD.f90/g' Makefile

sed -i 's/FF_Bq/FF_Bp/g' FB_MQC_timecorr_mD.f90
sed -i 's/posn/mom/g' FB_MQC_timecorr_mD.f90 
sed -i 's/TuningP/TuningQ/g' FB_MQC_timecorr_mD.f90
sed -i 's/torFB_Q/torFB_P/g' FB_MQC_timecorr_mD.f90
sed -i 's/FB_Bq/FB_Bp/g' FB_MQC_timecorr_mD.f90
sed -i 's/FBMQC_Bq/FBMQC_Bp/g' FB_MQC_timecorr_mD.f90

sed -i 's/,Initialq,/,Initialp,/g' FB_MQC_timecorr_mD.f90

sed -i 's/qpfwd(2,:,j) + dp(:)/qpfwd(2,:,j)/g' FB_MQC_timecorr_mD.f90
sed -i 's/qpfwd(1,:,j)/qpfwd(1,:,j) + dq(:)/g' FB_MQC_timecorr_mD.f90
sed -i 's/dp/dq/g' FB_MQC_timecorr_mD.f90

sed -i 's/vdv/vdv_AnHO/g' supply_mD.f90
sed -i 's/vdv/vdv_AnHO/g' traj_mD.f90
