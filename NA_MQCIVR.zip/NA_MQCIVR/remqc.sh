#!/bin/bash
rm mqcivr.*
