#!/bin/bash
echo 'Enter the dimensionality of the system'
read dimensions
echo 'Enter the tag of your potential subroutine'
read potential

if [ $dimensions -eq "1" ] 

then

sed -i "s/vdv_AnHO/$potential/g" supply_1D.f90
sed -i "s/vdv_AnHO/$potential/g" traj_1D.f90

sed -i "s/vdv_HO/$potential/g" supply_1D.f90
sed -i "s/vdv_HO/$potential/g" traj_1D.f90

else

sed -i "s/vdv_AnHO/$potential/g" supply_mD.f90
sed -i "s/vdv_AnHO/$potential/g" traj_mD.f90

sed -i "s/vdv_HO/$potential/g" supply_mD.f90
sed -i "s/vdv_HO/$potential/g" traj_mD.f90

fi
