#!/bin/bash
mkdir ../../EXPERIMENT
cp ../jobrun.sh ../../EXPERIMENT
cd ../../
cp makefiles/Makefile EXPERIMENT
cp supply/supply_mD.f90 EXPERIMENT
cp params/params_mD.f90 EXPERIMENT
cp timecorr/multiD/DHK_timecorr_mD.f90 EXPERIMENT
cp traj/traj_mD.f90 EXPERIMENT
cp monteCarlo/MonteCarlo_mD.f90 EXPERIMENT
cp potentials/potential_mD.f90 EXPERIMENT
cp theory.in input_mD
mv input_mD EXPERIMENT
cd Scripts/MoveFiles
